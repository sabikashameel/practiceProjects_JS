window.onload=function(){

    var istatus = document.querySelector("h4");
    var add = document.querySelector("#addfriend");

    var flag=0

    add.addEventListener("click", function(){
        if(flag==0){
            add.innerHTML="Remove Friend"
            istatus.innerHTML="Friend"
            istatus.style.color="green"
            flag=1
        }

        else{
            add.innerHTML="Add Friend"
            istatus.innerHTML="Stranger"
            istatus.style.color="Red"
            flag=0
        }
    })

}

















